# Introduction 
-   Clock with digital output is the project application that allows user to see time in digital format so user will understand the present time with this application .
## Features
-   It is a clock with digital output hence shows discrete values of time .
-   When get rebooted , output will not change .
### SWOT ANALYSIS
![SWOT](https://user-images.githubusercontent.com/101577287/163710077-f63ac154-ca86-4134-9f5e-decfdda4df89.png)
