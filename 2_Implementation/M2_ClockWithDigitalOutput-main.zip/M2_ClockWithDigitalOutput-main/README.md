# M2_ClockWithDigitalOutput
This is my project repository which contains project of embedded system

## BADGES

[![Codacy Badge](https://app.codacy.com/project/badge/Grade/1da3e6fa35d84e6a8e8d1d594be11968)](https://www.codacy.com/gh/ROHITVARSHNEY1122/M2_ClockWithDigitalOutput/dashboard?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=ROHITVARSHNEY1122/M2_ClockWithDigitalOutput&amp;utm_campaign=Badge_Grade)

[![Build CI-Linux](https://github.com/ROHITVARSHNEY1122/M2_ClockWithDigitalOutput/actions/workflows/c-build.yml/badge.svg)](https://github.com/ROHITVARSHNEY1122/M2_ClockWithDigitalOutput/actions/workflows/c-build.yml)

[![Makefile](https://github.com/ROHITVARSHNEY1122/M2_ClockWithDigitalOutput/actions/workflows/Makefile.yml/badge.svg)](https://github.com/ROHITVARSHNEY1122/M2_ClockWithDigitalOutput/actions/workflows/Makefile.yml)

[![Valgrind](https://github.com/ROHITVARSHNEY1122/M2_ClockWithDigitalOutput/actions/workflows/Valgrind.yml/badge.svg)](https://github.com/ROHITVARSHNEY1122/M2_ClockWithDigitalOutput/actions/workflows/Valgrind.yml)

[![cppcheck-action](https://github.com/ROHITVARSHNEY1122/M2_ClockWithDigitalOutput/actions/workflows/cppcheck.yml/badge.svg)](https://github.com/ROHITVARSHNEY1122/M2_ClockWithDigitalOutput/actions/workflows/cppcheck.yml)

[![Git Inspector](https://github.com/ROHITVARSHNEY1122/M2_ClockWithDigitalOutput/actions/workflows/gitinspector.yml/badge.svg)](https://github.com/ROHITVARSHNEY1122/M2_ClockWithDigitalOutput/actions/workflows/gitinspector.yml)
