![Structural](https://user-images.githubusercontent.com/101577287/163916454-b831a44f-e679-478b-b8a8-f0918c80ee8e.png)

