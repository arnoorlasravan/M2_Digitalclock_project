# Structural
![Structural](https://user-images.githubusercontent.com/101577287/163916702-e1c77a2b-acfb-48c4-8a4c-8b853cedaa1a.png)
## Behavioural
![BEHAVIOURAL](https://user-images.githubusercontent.com/101577287/163919911-aeba1def-3fef-4937-a6fb-0123efd3cb61.png)
### Block Diagram
![BLOCK DIAGRAM](https://user-images.githubusercontent.com/101577287/163925570-708745b3-8502-44b1-96a4-663a76f90b3c.png)
