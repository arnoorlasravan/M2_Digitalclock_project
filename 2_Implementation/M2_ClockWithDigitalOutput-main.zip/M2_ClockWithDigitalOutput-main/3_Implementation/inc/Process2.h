/**
 * @file Process2.h
 * @author Rohit Varshney
 * @brief Header file for ClockWithDigitalOutput
 *
 */
#ifndef PROCESS2_H_INCLUDED
#define PROCESS2_H_INCLUDED
void MinutesToCalculate(bool display_time);
#endif 

