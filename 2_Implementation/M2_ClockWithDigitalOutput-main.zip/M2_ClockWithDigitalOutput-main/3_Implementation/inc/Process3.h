/**
 * @file Process3.h
 * @author Rohit Varshney
 * @brief Header file for ClockWithDigitalOutput
 *
 */
#ifndef PROCESS3_H_INCLUDED
#define PROCESS3_H_INCLUDED
void HoursToCalculate(bool display_time);
#endif 
