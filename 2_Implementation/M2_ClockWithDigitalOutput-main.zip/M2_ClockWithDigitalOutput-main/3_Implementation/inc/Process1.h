/**
 * @file Process1.h
 * @author Rohit Varshney
 * @brief Header file for ClockWithDigitalOutput
 *
 */
#ifndef PROCESS1_H_INCLUDED
#define PROCESS1_H_INCLUDED
void SecondsToCalculate(bool display_time);
#endif 
