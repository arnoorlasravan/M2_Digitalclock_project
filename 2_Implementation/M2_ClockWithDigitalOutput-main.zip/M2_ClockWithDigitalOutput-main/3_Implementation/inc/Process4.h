/**
 * @file Process4.h
 * @author Rohit Varshney
 * @brief Header file for ClockWithDigitalOutput
 *
 */
#ifndef PROCESS4_H_INCLUDED
#define PROCESS4_H_INCLUDED
void Displayprinting(uint8_t DIGIT, uint8_t NUMBERDISPLAY);
#endif 


